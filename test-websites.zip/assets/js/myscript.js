var i = 4
var j = 9

alert( 'Welcome to my site')

var sum = function(a,b) {
    return a+b;
} ;
for (var i = 1; i <= 4 i++) {
    console.log(sum i,1);
}